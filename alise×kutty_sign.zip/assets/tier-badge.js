(function(){/* disabled - badge moved to native tab bar */})();
