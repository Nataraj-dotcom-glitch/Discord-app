(function () {
    'use strict';
    if (window.__dw11_diag) return;
    window.__dw11_diag = true;

    function report(msg) {
        if (window.MicStatus && window.MicStatus.report) window.MicStatus.report(msg);
    }

    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        navigator.mediaDevices.enumerateDevices().then(function (devs) {
            var mics = devs.filter(function (d) { return d.kind === 'audioinput'; });
            if (mics.length === 0) report('NO MIC DEVICE FOUND');
        }).catch(function () {});
    }

    var orig = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);

    function attempt(constraints, triesLeft) {
        return orig(constraints).then(function (stream) {
            try {
                var t = stream.getAudioTracks()[0];
                if (t) {
                    if (window.__dw11_stereoActive) {
                        report('MIC OK (2ch stereo)');
                    } else {
                        var s = t.getSettings();
                        report('MIC OK (' + (s.channelCount || '?') + 'ch)');
                    }
                }
            } catch (ignore) {}
            return stream;
        }).catch(function (e) {
            if (triesLeft > 0 && e && (e.name === 'NotReadableError' || e.name === 'AbortError')) {
                return new Promise(function (resolve, reject) {
                    setTimeout(function () {
                        attempt(constraints, triesLeft - 1).then(resolve, reject);
                    }, 500);
                });
            }
            var c = (e && e.constraint) ? ' (' + e.constraint + ')' : '';
            report('Mic blocked: ' + (e && e.name ? e.name : 'unknown') + c);
            throw e;
        });
    }

    navigator.mediaDevices.getUserMedia = function (constraints) {
        return attempt(constraints, 3);
    };
})();
